# Base de données utilisée pour le site développé dans le cadre d'une SAE.
[lien du site](https://jupyter.univ-paris13.fr/~12206971/PerformVision/)

- Un schéma entité associations version looping et version pdf
- Script de création de la base de données
- Script de peuplement
- Graphe des dépendances fonctionnelles
- Powerpoint de la soutenance
